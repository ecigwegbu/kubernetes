#!/bin/bash

# Auxilliary code to package the files for the K8s cluster

tar czf ansible-playbooks.tar.gz *.yml Vagrantfile aliases post-install.sh README.md package.sh
