#!/bin/bash

alias ap='ansible-playbook'
alias apc='ansible-playbook -C'
alias apsc='ansible-playbook --syntax-check'
alias lll='ls -larth'
